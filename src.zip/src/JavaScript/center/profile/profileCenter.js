import ReadContents from "../common/ReadContents";

const ShowProfile = (userId) => {
        return(
            <div>
                <div>name space</div>
                <div>banner space</div>
                <div>info space</div>
                <div>select space</div>
                <ReadContents/>
            </div>
        );
};

export default ShowProfile;