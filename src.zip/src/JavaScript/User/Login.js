import "../../CSS/User/Login.css";
import UiForm from "./UiForm";


const Login = () => {
    return (
      <div className="Login">
        <UiForm></UiForm>
      </div>
    )
};

export default Login;