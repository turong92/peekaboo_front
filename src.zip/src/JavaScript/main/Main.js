import React, { Component } from 'react';
import "../../CSS/main/Main.css";

class Main extends Component {
      render(){
    return (
      <div className="Main">
          Hi im main
      </div>
    );
  }
}

export default Main;